# --------------------------------------------------------------
# Create a Snake Game using the turtle, random and time library
# --------------------------------------------------------------

# Importing libraries
import turtle
import random
import time

# define the speed delay
sdp_dly = 0.1

# score virables
Score = 0
High_Score = 0

# Creating The Main Window Of The Game
wn = turtle.Screen()
wn.title("BOUTI Snake Game In Python")
wn.bgcolor("black")
wn.setup(width=620, height=680)
wn.tracer(0)

# Drawing Borders
pen = turtle.Turtle()
pen.color("grey")
pen.penup()
pen.setposition(-300, -300)
pen.pendown()
pen.pensize(3)
for side in range(4):
    pen.forward(600)
    pen.left(90)
pen.hideturtle()

# Snake's Head
head = turtle.Turtle()
head.shape("circle")
head.color("blue")
head.penup()
head.goto(0, 0)
head.direction = "Stop"

# Snake's Food
food = turtle.Turtle()
food.shape("circle")
food.color("red")
food.penup()
food.goto(0, 100)

# Define A List Called Body
Body = []

# Score Board
text = turtle.Turtle()
text.shape("square")
text.color("white")
text.penup()
text.hideturtle()
text.goto(0, 300)
text.write("Score: 0 High Score: 0", align="center",
           font=("Times New Roman", 24, "normal"))


# Functions
def movement():
    if head.direction == "up":
        y = head.ycor()
        head.sety(y + 20)
    if head.direction == "down":
        y = head.ycor()
        head.sety(y - 20)
    if head.direction == "left":
        x = head.xcor()
        head.setx(x - 20)
    if head.direction == "right":
        x = head.xcor()
        head.setx(x + 20)


# Controls
def move_up():
    if head.direction != "down":
        head.direction = "up"


def move_down():
    if head.direction != "up":
        head.direction = "down"


def move_left():
    if head.direction != "right":
        head.direction = "left"


def move_right():
    if head.direction != "left":
        head.direction = "right"


# Keyboard Syncing
wn.listen()
wn.onkeypress(move_up, "Up")
wn.onkeypress(move_down, "Down")
wn.onkeypress(move_left, "Left")
wn.onkeypress(move_right, "Right")

# Central Loop
while True:
    wn.update()

    # Checking Head Collision With Borders
    if head.xcor() > 290 or head.xcor() < -290 or head.ycor() > 290 or head.ycor() < -290:
        time.sleep(1)
        head.goto(0, 0)
        head.direction = "Stop"

        # Hiding Body Parts
        for parts in Body:
            parts.goto(1000, 1000)

        # Clearing Body List
        Body.clear()

        # Resetting The Score Back To 0
        Score = 0

        # Resetting The Time Delay After Collision
        sdp_dly = 0.1

        # Updating Score Board
        text.clear()
        text.write("Score: {} High Score: {}".format(Score, High_Score),
                   align="center", font=("Times New Roman", 24, "normal"))

    # Collision And Randomisation Of Food
    if head.distance(food) < 20:
        x = random.randint(-290, 290)
        y = random.randint(-290, 290)
        food.goto(x, y)

        # Adding Body Parts
        newBody = turtle.Turtle()
        newBody.shape("circle")
        newBody.color("lightblue")
        newBody.penup()
        Body.append(newBody)

        # Shortening The Time Delay By Decrementation
        sdp_dly -= 0.001

        # Increasing Score By Incrementation
        Score += 10

        if Score > High_Score:
            High_Score = Score
        text.clear()
        text.write("Score: {} High Score: {}".format(Score, High_Score),
                   align="center", font=("Times New Roman", 24, "normal"))

    for index in range(len(Body)-1, 0, -1):
        x = Body[index-1].xcor()
        y = Body[index-1].ycor()
        Body[index].goto(x, y)

    # Moving Body Part 0 To Heads Place
    if len(Body) > 0:
        x = head.xcor()
        y = head.ycor()
        Body[0].goto(x, y)
    movement()

    # Creating Head Collision With Body Parts
    for parts in Body:
        if parts.distance(head) < 20:
            time.sleep(1)
            head.goto(0, 0)
            head.direction = "Stop"

        # Hiding Body Parts
            for parts in Body:
                parts.goto(1000, 1000)

        # Clearing Body List
            Body.clear()
    time.sleep(sdp_dly)

# Run Game Infinitely
wn.mainloop()
